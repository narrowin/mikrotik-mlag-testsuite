# SPDX-FileCopyrightText: 2025-present Network Team <network@company.com>
#
# SPDX-License-Identifier: MIT
"""Support for creating device configurations from IP addresses."""

from __future__ import annotations

import ipaddress

from network_toolkit.config import DeviceConfig, NetworkConfig
from network_toolkit.transport.scrapli_sync import (
    SCRAPLI_PLATFORM_ALIASES,
    get_scrapli_definition_catalog,
)


def ip_device_name(address: str) -> str:
    """Return the inventory name used for an ad-hoc IP target."""
    if ":" in address:
        # Escape underscores first so IPv6 punctuation stays unambiguous.
        address = address.replace("_", "__").replace(":", "_c").replace(".", "_d")
        return f"ip_{address}"
    return f"ip_{address.replace('.', '_')}"


def is_ip_address(target: str) -> bool:
    """
    Check if a string is a valid IP address.

    Parameters
    ----------
    target : str
        String to check

    Returns
    -------
    bool
        True if target is a valid IP address
    """
    try:
        ipaddress.ip_address(target)
        return True
    except ValueError:
        return False


def is_ip_list(target: str) -> bool:
    """
    Check if a string is a comma-separated list of IP addresses.

    Parameters
    ----------
    target : str
        String to check

    Returns
    -------
    bool
        True if all comma-separated parts are valid IP addresses
    """
    if "," not in target:
        return is_ip_address(target)

    parts = [part.strip() for part in target.split(",")]
    return all(is_ip_address(part) for part in parts if part)


def extract_ips_from_target(target: str) -> list[str]:
    """
    Extract IP addresses from a target string.

    Parameters
    ----------
    target : str
        Target string (single IP or comma-separated IPs)

    Returns
    -------
    list[str]
        List of IP addresses
    """
    if "," not in target:
        return [target.strip()]

    return [ip.strip() for ip in target.split(",") if ip.strip()]


def create_ip_device_config(
    ip: str,
    device_type: str,
    hardware_platform: str | None = None,
    port: int | None = None,
    transport_type: str | None = None,
) -> DeviceConfig:
    """
    Create a DeviceConfig from an IP address and device type.

    Parameters
    ----------
    ip : str
        IP address of the device
    device_type : str
        Network driver type identifier (e.g., 'mikrotik_routeros', 'cisco_iosxe')
        This determines which Scrapli/transport driver to use for connections.
        Must be a valid SupportedDeviceType.
    hardware_platform : str | None
        Hardware platform architecture (e.g., 'x86', 'arm', 'tile')
        Used for firmware operations. Optional.
    port : int | None
        SSH port, defaults to 22 if not provided
    transport_type : str | None
        Transport type (currently only 'scrapli' is supported)
        Defaults to configuration or 'scrapli'

    Returns
    -------
    DeviceConfig
        Device configuration for the IP
    """
    # Validate IP address
    try:
        ipaddress.ip_address(ip)
    except ValueError as e:
        msg = f"Invalid IP address '{ip}': {e}"
        raise ValueError(msg) from e

    available_types = get_supported_device_types()
    if device_type not in available_types:
        supported = ", ".join(available_types)
        msg = f"Unsupported device_type '{device_type}'. Supported types: {supported}"
        raise ValueError(msg)

    # Default port to 22 if not provided
    if port is None:
        port = 22

    return DeviceConfig(
        host=ip,
        description=f"Dynamic device at {ip}",
        device_type=device_type,  # Validated above
        platform=hardware_platform,
        port=port,
        transport_type=transport_type,
    )


def create_ip_based_config(
    ips: list[str],
    device_type: str,
    base_config: NetworkConfig,
    hardware_platform: str | None = None,
    port: int | None = None,
    transport_type: str | None = None,
) -> NetworkConfig:
    """
    Create a NetworkConfig with IP-based device configurations.

    Parameters
    ----------
    ips : list[str]
        List of IP addresses to create device configurations for
    device_type : str
        Network driver type for all IP devices (e.g., 'mikrotik_routeros')
    base_config : NetworkConfig
        Base configuration to extend with IP devices
    hardware_platform : str | None
        Hardware platform architecture for all IP devices (e.g., 'x86', 'arm')
    port : int | None
        SSH port for all IP devices, defaults to 22
    transport_type : str | None
        Transport type for all IP devices (currently only 'scrapli' is supported)

    Returns
    -------
    NetworkConfig
        Enhanced configuration including IP-based devices
    """
    ip_devices: dict[str, DeviceConfig] = {}

    for ip in ips:
        # Create a device name from the IP
        device_name = ip_device_name(ip)
        existing = ip_devices.get(device_name) or (base_config.devices or {}).get(
            device_name
        )
        if existing is not None and existing.host != ip:
            msg = f"IP target '{ip}' conflicts with inventory device '{device_name}'"
            raise ValueError(msg)
        ip_devices[device_name] = create_ip_device_config(
            ip, device_type, hardware_platform, port, transport_type
        )

    # Create new config with IP devices combined with existing devices
    combined_devices: dict[str, DeviceConfig] = {}
    if base_config.devices:
        combined_devices.update(base_config.devices)
    combined_devices.update(ip_devices)

    # Create new NetworkConfig with combined devices
    config_dict = base_config.model_dump()
    config_dict["devices"] = combined_devices

    new_config = NetworkConfig.model_validate(config_dict)

    # Preserve the config source directory from the base config
    if hasattr(base_config, "_config_source_dir"):
        new_config._config_source_dir = base_config._config_source_dir

    return new_config


def get_supported_device_types() -> dict[str, str]:
    """
    Get device types accepted for ad hoc connections.

    Returns
    -------
    dict[str, str]
        Mapping of device type names to descriptions
    """
    # Map device types to human-readable descriptions
    descriptions = {
        "mikrotik_routeros": "MikroTik RouterOS",
        "cisco_iosxe": "Cisco IOS-XE",
        "cisco_ios": "Cisco IOS",
        "cisco_iosxr": "Cisco IOS-XR",
        "cisco_nxos": "Cisco NX-OS",
        "juniper_junos": "Juniper JunOS",
        "arista_eos": "Arista EOS",
        "nokia_srlinux": "Nokia SR Linux",
        "linux": "Linux SSH",
        "generic": "Generic SSH",
    }

    exact_names, _ = get_scrapli_definition_catalog()
    supported_types = exact_names - SCRAPLI_PLATFORM_ALIASES.keys()
    supported_types.update(
        alias
        for alias, definition in SCRAPLI_PLATFORM_ALIASES.items()
        if (definition or "default") in exact_names
    )

    return {name: descriptions.get(name, name) for name in sorted(supported_types)}


def validate_platform(device_type: str) -> bool:
    """
    Validate if a device type is supported.

    Parameters
    ----------
    device_type : str
        Device type identifier to validate

    Returns
    -------
    bool
        True if device type is supported
    """
    return device_type in get_supported_device_types()
