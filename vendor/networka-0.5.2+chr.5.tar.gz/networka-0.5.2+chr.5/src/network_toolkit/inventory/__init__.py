"""Inventory backends and adapters."""
