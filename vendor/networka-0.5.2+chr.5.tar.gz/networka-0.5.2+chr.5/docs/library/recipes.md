# Code Recipes

Common patterns for Networka library usage.

## Multi-Command Workflow

Execute a sequence of commands with validation using `client.run()`:

```python
from network_toolkit import NetworkaClient

with NetworkaClient() as client:
    # Check current state
    identity = client.run("router1", "/system/identity/print")
    if identity.command_results:
        print(f"Connected to: {identity.command_results[0].output}")

    # Get system info
    resources = client.run("router1", "/system/resource/print")
    if resources.command_results:
        print(f"Resources: {resources.command_results[0].output}")

    # Check interfaces
    interfaces = client.run("router1", "/interface/print")
    if interfaces.command_results:
        print(f"Interfaces: {interfaces.command_results[0].output}")
```

## Parallel Device Operations

Run the same command on multiple devices simultaneously. Each worker uses a client context to close its sessions.

```python
from concurrent.futures import ThreadPoolExecutor, as_completed
from network_toolkit import NetworkaClient


def get_device_info(device_name):
    """Execute command on a single device."""
    try:
        with NetworkaClient() as client:
            result = client.run(device_name, "/system/identity/print")
        if not result.command_results:
            return {"device": device_name, "output": None, "error": "No command result"}
        command = result.command_results[0]
        return {"device": device_name, "output": command.output, "error": command.error}
    except Exception as e:
        return {"device": device_name, "output": None, "error": str(e)}


devices = ["router1", "router2", "router3", "router4"]

results = []
with ThreadPoolExecutor(max_workers=4) as executor:
    futures = {executor.submit(get_device_info, dev): dev for dev in devices}

    for future in as_completed(futures):
        result = future.result()
        results.append(result)
        if result["error"]:
            print(f"ERROR on {result['device']}: {result['error']}")
        else:
            print(f"SUCCESS on {result['device']}: {result['output']}")

# Summary
success = sum(1 for r in results if not r["error"])
print(f"\nCompleted: {success}/{len(devices)} successful")
```

## Check collected output

Collect several read-only replies with one session and distinguish a device
error from a command that returns empty text.

```python
from network_toolkit import NetworkaClient

checks = {
    "identity": "/system/identity/print",
    "resources": "/system/resource/print",
}

with NetworkaClient() as client:
    for label, command in checks.items():
        result = client.run("router1", command)
        if not result.command_results:
            print(f"{label}: no command result")
            continue

        response = result.command_results[0]
        if response.error is not None:
            print(f"{label}: {response.error}")
        elif response.output:
            print(f"{label}: {response.output}")
        else:
            print(f"{label}: empty response")
```

## Backup and Download

Create a backup and download it:

```python
from pathlib import Path
from network_toolkit import NetworkaClient

client = NetworkaClient()

# Method 1: Using NetworkaClient.backup()
result = client.backup(
    target="router1",
    download=True,
    delete_remote=True,  # Clean up after download
)

for backup in result.device_results:
    if backup.success:
        print(f"{backup.device}: {backup.backup_dir}")

# Method 2: Using DeviceSession for more control
from network_toolkit import DeviceSession

with DeviceSession("router1", client.config) as session:
    # Create backup
    session.execute_command("/system/backup/save name=mybackup")

    # Download it
    local_path = Path("./backups/router1-backup.backup")
    session.download_file(remote_filename="mybackup.backup", local_path=local_path)

    # Delete remote backup
    session.execute_command("/file/remove mybackup.backup")

    print(f"Backup downloaded to: {local_path}")
```

## Upload and Execute Script

Upload a RouterOS script and run it:

```python
from pathlib import Path
from network_toolkit import NetworkaClient, DeviceSession

client = NetworkaClient()

script_content = """
/system identity set name=NewHostname
/log info "Script executed successfully"
"""

# Save script locally
script_file = Path("temp_script.rsc")
script_file.write_text(script_content)

try:
    with DeviceSession("router1", client.config) as session:
        # Upload script
        session.upload_file(local_path=script_file, remote_filename="temp_script.rsc")

        # Execute it
        output = session.execute_command("/import temp_script.rsc")
        print(f"Script output: {output}")

        # Clean up
        session.execute_command("/file/remove temp_script.rsc")
finally:
    # Clean up local file
    script_file.unlink()
```

## Configuration Diff

Compare current config against saved output:

```python
from pathlib import Path

from network_toolkit import NetworkaClient

with NetworkaClient() as client:
    result = client.diff(
        targets="router1",
        subject="/export",
        saved_output=Path("./saved/router1.rsc"),
    )

for item in result.results:
    if item.error is not None:
        print(f"{item.device}: {item.error}")
    elif item.outcome is not None and item.outcome.changed:
        print(item.outcome.output)
    else:
        print(f"{item.device}: No differences")
```

## Error Handling Pattern

Robust error handling for production use:

```python
from network_toolkit import NetworkaClient, DeviceSession
from network_toolkit.exceptions import (
    DeviceConnectionError,
    DeviceExecutionError,
    NetworkToolkitError,
)

client = NetworkaClient()


def safe_execute(device_name, command, config):
    """Execute command with comprehensive error handling."""
    try:
        with DeviceSession(device_name, config) as session:
            output = session.execute_command(command)
            return {"success": True, "output": output, "error": None}

    except DeviceConnectionError as e:
        return {
            "success": False,
            "output": None,
            "error": f"Connection failed: {e.message}",
        }

    except DeviceExecutionError as e:
        return {
            "success": False,
            "output": None,
            "error": f"Command failed: {e.message}",
        }

    except NetworkToolkitError as e:
        return {
            "success": False,
            "output": None,
            "error": f"Networka error: {e.message}",
        }

    except Exception as e:
        return {
            "success": False,
            "output": None,
            "error": f"Unexpected error: {str(e)}",
        }


result = safe_execute("router1", "/system/identity/print", client.config)
if result["success"]:
    print(f"Output: {result['output']}")
else:
    print(f"Error: {result['error']}")
```

## Credential Management

Load credentials from environment or vault:

```python
import os
from network_toolkit import NetworkaClient, DeviceSession, InteractiveCredentials


def get_credentials():
    """Load credentials from environment."""
    return InteractiveCredentials(
        username=os.getenv("DEVICE_USER", "admin"),
        password=os.getenv("DEVICE_PASSWORD", ""),
    )


client = NetworkaClient()
creds = get_credentials()

with DeviceSession(
    "router1",
    client.config,
    username_override=creds.username,
    password_override=creds.password,
) as session:
    output = session.execute_command("/system/identity/print")
    print(output)
```

## Reference Implementation

See `scripts/lib_demo_networka_programmatic.py` in the repository for a complete example that demonstrates:

- Target selection strategies (config vs ad-hoc IP)
- Persistent sessions for multiple commands
- Progress tracking with Rich
- Compliance validation
- Table-formatted results
- Error handling

Run it with:

```bash
uv run scripts/lib_demo_networka_programmatic.py
```

## Next Steps

- Review the [API reference](../reference/api.md) for all available methods
- See [sessions documentation](sessions.md) for connection management details
- Check [ad-hoc targeting](adhoc-targets.md) for IP-based connections
