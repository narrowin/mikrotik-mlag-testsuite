# Persistent Sessions

## Automatic Session Management

`NetworkaClient` automatically manages SSH sessions for you. When you run a command, it checks if a connection to that device already exists. If so, it reuses it; if not, it opens a new one.

If a pooled session cannot connect, the client replaces it once. If a session loses its connection during a command, the call reports the error and the client closes that session and removes it from the pool. Networka does not send the command again, because the device may already have run it. The next call to that device opens a new session.

To ensure these connections are closed properly when you are done, you should use the client as a context manager.

**Recommended Pattern:**

```python
from network_toolkit import NetworkaClient

# The 'with' block ensures all connections are closed when done
with NetworkaClient() as client:
    # First command opens the connection
    client.run("router1", "show version")

    # Subsequent commands reuse the same connection automatically
    client.run("router1", "show ip int brief")

    # You can switch between devices freely
    client.run("switch1", "show vlan")  # Opens new connection to switch1
    client.run("router1", "show clock")  # Reuses existing connection to router1

# All sessions (router1, switch1) are closed here
```

## Manual Management (Not Recommended)

If you do not use the context manager, connections will remain open until the script terminates or you manually close them. This can lead to resource leaks in long-running scripts.

```python
client = NetworkaClient()

# Opens connection and keeps it open
client.run("router1", "show version")

# Reuses connection
client.run("router1", "show ip int brief")

# You must manually close sessions to free resources
client.close()
```

## Advanced: Low-Level Session Control

For very specific use cases where you need direct control over a single session (bypassing the client's pool), you can use `DeviceSession` directly. This is rarely needed as `client.run()` handles session reuse automatically.

```python
from network_toolkit import DeviceSession

# Manually manage a single session
with DeviceSession("router1", client.config) as session:
    output = session.execute_command("show version")
```

## File Transfer

For file transfers, use the high-level client methods which handle connection management automatically.

### Upload

Transfer a file to the device:

```python
client.upload(
    target="router1", local_file="firmware.npk", remote_filename="firmware.npk"
)
```

### Download

Download a file from the device:

```python
client.download(
    target="router1", remote_file="backup.rsc", local_path="./backups/backup.rsc"
)
```

## Custom Credentials

Override credentials without changing configuration by passing `interactive_creds` to `client.run()`:

```python
from network_toolkit.common.credentials import InteractiveCredentials

# Create credentials object
creds = InteractiveCredentials(
    username="admin",
    password="secret_password",  # pragma: allowlist secret
)

# Use credentials for this specific run
client.run("router1", "show version", interactive_creds=creds)
```

## Error Handling

Sessions automatically handle connection cleanup, even on errors:

```python
try:
    with DeviceSession("router1", client.config) as session:
        output = session.execute_command("/some/command")
        # Process output...
        if "error" in output.lower():
            raise ValueError("Command returned error")
except ValueError as e:
    print(f"Command failed: {e}")
# Connection still closes properly
```

`execute_command` raises `DeviceExecutionError` when the device rejects a command, and the message includes the device's reply. On RouterOS, replies that start with `syntax error`, `bad command name`, `expected end of command`, `input does not match any value`, `failure:` or `no such item` count as rejected. A connection failure raises `DeviceConnectionError` with the reason, and a rejected login raises its subclass `DeviceAuthError`.

`client.run()` does not raise for device failures. It reports them in `DeviceCommandResult.error` or `DeviceSequenceResult.error`, with the connection reason or the device's reply. A sequence stops at its first failed command, and `DeviceSequenceResult.outputs` keeps the outputs of the commands that ran before it.

## Logging

Networka does not configure logging when you use it as a library, and it prints nothing by default. Networka logs under the `network_toolkit` logger and Scrapli under `scrapli`. To see their records, configure logging in your application:

```python
import logging

logging.basicConfig(level=logging.WARNING)
```

## Parallel Sessions

Run commands on multiple devices simultaneously:

```python
from concurrent.futures import ThreadPoolExecutor
from network_toolkit import NetworkaClient, DeviceSession


def check_device(device_name, config):
    with DeviceSession(device_name, config) as session:
        return session.execute_command("/system/identity/print")


client = NetworkaClient()
devices = ["router1", "router2", "router3"]

with ThreadPoolExecutor(max_workers=3) as executor:
    futures = [executor.submit(check_device, dev, client.config) for dev in devices]
    for future in futures:
        print(future.result())
```

See [recipes](recipes.md) for more parallel operation patterns.

## Configuration

Sessions respect configuration settings:

```yaml
general:
  connection_retries: 3
  retry_delay: 2
  ssh_strict_host_key_checking: true
  ssh_known_hosts_file: ~/lab/known_hosts
```

Disable strict host key checking programmatically:

```python
client = NetworkaClient()
client.config.general.ssh_strict_host_key_checking = False

with DeviceSession("router1", client.config) as session:
    output = session.execute_command("show version")
```

## Next Steps

- See [recipes](recipes.md) for complete workflow examples
- Check [ad-hoc targets](adhoc-targets.md) for connecting without configuration
- Review [API reference](../reference/api.md) for all methods and parameters
