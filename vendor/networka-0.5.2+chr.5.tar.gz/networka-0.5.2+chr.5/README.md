<div align="center"><img src="https://narrowin.github.io/networka/assets/images/networka_readme.png" alt="Networka Logo" width="320"/>

  <p><a href="https://narrowin.github.io/networka/">Full documentation →</a></p>
</div>

<br/>

Networka is a lightweight CLI for network engineers and integrators. Run ad hoc
commands or reusable sequences across network devices from multiple vendors,
then save the output and later compare a device with that saved output.

Use Networka for on-demand troubleshooting and before-and-after checks. Pair it
with continuous monitoring for alerting, telemetry, and ongoing checks.

[![Python 3.15+](https://img.shields.io/badge/python-3.15%2B-blue.svg)](https://www.python.org/downloads/)
[![Platform](https://img.shields.io/badge/platform-Linux%20%7C%20macOS%20arm64-lightgrey.svg)](https://github.com/narrowin/networka)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://www.apache.org/licenses/LICENSE-2.0)
[![Code style: ruff](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff)
[![Type checked with mypy](https://img.shields.io/badge/mypy-checked-blue.svg)](http://mypy-lang.org/)
[![Docs](https://img.shields.io/github/actions/workflow/status/narrowin/networka/docs.yml?label=Docs&logo=github)](https://narrowin.github.io/networka/)

## Getting Started

- Installation: see the docs → https://narrowin.github.io/networka/getting-started/
- Platform compatibility → https://narrowin.github.io/networka/platform-compatibility/
- Shell completion → https://narrowin.github.io/networka/shell-completion/
- CLI reference → https://narrowin.github.io/networka/reference/cli/
- API reference → https://narrowin.github.io/networka/reference/api/

See how to [run a reusable sequence](https://narrowin.github.io/networka/running-commands/),
[save the output](https://narrowin.github.io/networka/results/), and
[compare it with saved output](https://narrowin.github.io/networka/reference/cli/#nw-diff).

<div align="center">
  <img src="https://narrowin.github.io/networka/assets/gifs/networka-setup.gif" alt="Networka Setup Demo" width="800"/>
  <p><em>Networka setup and command execution demo</em></p>
</div>

## Networka vs the alternatives

| | Networka | Ansible | Nornir |
|---|---|---|---|
| Primary interface | CLI commands | YAML playbooks | Python scripts |
| Time to first command | Seconds after install | After writing playbook + inventory | After writing Python script |
| Learning curve | Familiar CLI patterns | YAML, Jinja2, modules | Python programming |
| Execution | Concurrent by default | Sequential by default | Depends on implementation |
| Best for | Daily operations, ad-hoc commands | Infrastructure-as-code, compliance | Custom automation frameworks |

Networka is built for network engineers who want to run commands now. Ansible excels at declarative infrastructure-as-code. Nornir shines when you need full Python programmability. Different tools, each great at what they do.

## Features

### **Core Capabilities**

- **Multi-vendor network automation**: Native support for MikroTik RouterOS, Cisco IOS/IOS-XE/NX-OS, Arista EOS, Juniper JunOS, and more
- **Scalable device management**: Execute commands across individual devices or groups
- **Cross-platform compatibility**: Scrapli 2 wheels for Linux and Apple Silicon
- **Flexible configuration**: YAML and CSV configuration options with powerful device tagging and grouping

### **Operational Features**

- **Command execution**: Run single commands or predefined sequences across devices and groups
- **File management**: Upload/download files to/from network devices with verification and error handling
- **Device backup**: Automated configuration and comprehensive backups with vendor-specific implementations
- **Firmware management**: Upgrade, downgrade, and BIOS operations with platform validation
- **CLI session management**: Direct CLI access with tmux integration for interactive sessions
- [**Lab tests and state checks**](https://github.com/narrowin/networka/blob/main/docs/lab-tests.md) check that devices are in the planned state and measure traffic while the network changes. `nw intent` checks device state on any device whose platform has checks, today MikroTik RouterOS and Linux. `nw test` adds ping measurement and actions such as cable changes, reboots and injected faults, and it runs against containerlab labs. Both save their evidence and can replay it without the lab or the devices. The [Small MLAG lab](https://github.com/narrowin/mikrotik-mlag-testsuite/blob/main/tests/small/README.md) has runnable examples.

### **Advanced Features**

- **Intelligent completions**: Context-aware shell completions for devices, groups, and sequences
- **Vendor-aware sequences**: Predefined command sets optimized for different network platforms
- **Results management**: Organized storage with multiple output formats and automatic timestamping
- **Configuration validation**: Schema-based validation with detailed error reporting
- **Credential management**: Secure credential handling via environment variables with device-specific overrides

### **Developer & Integration Features**

- **Type safety**: Full mypy type checking for reliability and maintainability
- **Modern architecture**: Built with scalable scrapli and nornir support
- **Extensible design**: Plugin-friendly architecture for adding new vendors and operations
- **Rich output**: Professional CLI interface with color coding and structured information display

## Installation

### System Requirements

- **Operating System**: Linux x86-64/arm64 or macOS arm64
- **Python**: 3.15 or later
- **Network Access**: SSH connectivity to target devices
- **Package Manager**: uv (recommended) or pip
- **tmux for `nw cli`**: Install tmux to use the multi-pane CLI command (`brew install tmux` on macOS, `apt install tmux` on Debian/Ubuntu). libtmux is installed automatically with Networka.

### Install from the checkout

With uv 0.13.10 in this checkout, use a project environment to keep the native driver isolated.

```bash
uv sync --locked
uv run --locked nw --version
uv run --locked nw --help
```

Networka uses Scrapli 2 via the `scrapli==2026.11.12` distribution. An in-place upgrade replaces legacy Scrapli through pip or uv. Early candidate installations that included `scrapli2==2.0.4` should use a fresh environment. [Transport selection](https://narrowin.github.io/networka/transport/) · [Platform compatibility](https://narrowin.github.io/networka/platform-compatibility/)

## Quick Start

Inspect a packaged sequence and run it on a RouterOS device. Replace the
example address and enter your device credentials when prompted.

```bash
nw info system_info --vendor mikrotik_routeros
nw run 192.0.2.10 system_info --platform mikrotik_routeros --interactive-auth
```

For recurring work, use `nw config init` to create your
[configuration](https://narrowin.github.io/networka/configuration/) and target devices by name.

### Library API

Use Networka programmatically in your Python applications:

```python
from network_toolkit import NetworkaClient, DeviceSession

client = NetworkaClient()

with DeviceSession("router1", client.config) as session:
    output = session.execute_command("show version")
    print(output)
```

See the [Library Documentation](https://narrowin.github.io/networka/library/) for:

- Multi-command workflows with persistent sessions
- Ad-hoc IP targeting without configuration files
- Credential handling patterns
- Integration recipes

### One-liners (no config)

Run directly against an IP without creating files. `--platform` selects the network OS driver; `--interactive-auth` prompts for credentials.

```bash
# MikroTik RouterOS
nw run --platform mikrotik_routeros 192.0.2.10 "/system/identity/print" --interactive-auth
```

```bash
# Cisco IOS-XE
nw run --platform cisco_iosxe 198.51.100.20 "show version" --interactive-auth
```

## Terminology: device_type vs hardware platform vs transport

- `device_type` is the logical platform used to select commands and the native connection definition.
- The inventory `platform` field describes hardware architecture for firmware.
- `--platform` names the logical platform for a raw IP target.
- `--transport` selects the Scrapli driver family. The underlying connection backend defaults to OpenSSH. [Transport settings](https://narrowin.github.io/networka/transport/)

## Quick links

- Getting started → https://narrowin.github.io/networka/getting-started/
- Running commands → https://narrowin.github.io/networka/running-commands/
- Configuration → https://narrowin.github.io/networka/configuration/
- Environment variables → https://narrowin.github.io/networka/environment-variables/
- Results → https://narrowin.github.io/networka/results/
- Output modes → https://narrowin.github.io/networka/output-modes/
- Backups → https://narrowin.github.io/networka/backups/
- CLI reference → https://narrowin.github.io/networka/reference/cli/
- API reference → https://narrowin.github.io/networka/reference/api/

## CLI overview

- For current usage and commands, see the CLI reference:
  - https://narrowin.github.io/networka/reference/cli/
  - Quick checks: `nw --help` and `nw --version`

## Community & support

- Visit our [documentation](https://narrowin.github.io/networka/) for detailed guides and examples
- Create [GitHub Issues](https://github.com/narrowin/networka/issues) for bug reports and feature requests
- See [CONTRIBUTING.md](https://github.com/narrowin/networka/blob/main/CONTRIBUTING.md) for contribution guidelines
- Check [SECURITY.md](https://github.com/narrowin/networka/blob/main/SECURITY.md) for security policy and reporting vulnerabilities

## Contributing

Have a look through existing [Issues](https://github.com/narrowin/networka/issues) and [Pull Requests](https://github.com/narrowin/networka/pulls) that you could help with. If you'd like to request a feature or report a bug, please create a GitHub Issue using one of the templates provided.

[See contribution guide →](https://github.com/narrowin/networka/blob/main/CONTRIBUTING.md)

## Documentation

- Docs Home → https://narrowin.github.io/networka/
- Platform Compatibility → https://narrowin.github.io/networka/platform-compatibility/
- Development Guide → https://narrowin.github.io/networka/development/
- Multi-Vendor Support → https://narrowin.github.io/networka/multi-vendor-support/
- IP Address Support → https://narrowin.github.io/networka/ip-address-support/
- Transport Selection → https://narrowin.github.io/networka/transport/
- Environment Variables → https://narrowin.github.io/networka/environment-variables/
- File Upload Guide → https://narrowin.github.io/networka/file_upload/
- Interactive Credentials → https://narrowin.github.io/networka/interactive-credentials/

## License

Apache License 2.0 - Free for commercial and personal use.
No paid tiers, no enterprise versions, no licensing restrictions.

Community-driven project with contributions from [narrowin](https://narrowin.ch/en/about.html) and network engineers worldwide.
See [GOVERNANCE.md](https://github.com/narrowin/networka/blob/main/GOVERNANCE.md) for maintenance and decision-making model.

## Acknowledgments

- [Scrapli](https://github.com/carlmontanari/scrapli) - Network device connections
- [Nornir](https://github.com/nornir-automation/nornir) - Network automation framework
- [Netmiko](https://github.com/ktbyers/netmiko) - Multi-vendor CLI connections to network devices
- [Typer](https://github.com/tiangolo/typer) - CLI framework
- [Pydantic](https://github.com/pydantic/pydantic) - Data validation
- [Rich](https://github.com/Textualize/rich) - Terminal formatting

---

_Built for network engineers who value clean, reliable automation_
